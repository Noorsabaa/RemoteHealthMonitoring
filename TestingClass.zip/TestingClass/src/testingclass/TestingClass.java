/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testingclass;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.awt.Desktop;
import java.net.URI;
import java.time.LocalDateTime;



// class EmergencyAlert that checks the vitals and triggers alarms
class EmergencyAlert {
    private double heartRate;
    private double bloodPressure;
    
    private static final double MAX_HEART_RATE = 120.0;
    private static final double MIN_HEART_RATE = 50.0;
    private static final double MAX_BLOOD_PRESSURE = 180.0; 
    private static final double MIN_BLOOD_PRESSURE = 80.0;

    public EmergencyAlert(double heartRate, double bloodPressure) {
        this.heartRate = heartRate;
        this.bloodPressure = bloodPressure;
    }

    public void checkAndTriggerAlert(Scanner scanner) {
    try {
        if (heartRate > MAX_HEART_RATE || heartRate < MIN_HEART_RATE ||
            bloodPressure > MAX_BLOOD_PRESSURE || bloodPressure < MIN_BLOOD_PRESSURE) {
            
            System.out.println("Critical vitals detected! Triggering emergency alert.");

            // Ask for recipient email ONLY when alert is needed
            System.out.print("Enter recipient email address (e.g., doctor@example.com): ");
            String recipientEmail = scanner.nextLine();
            NotificationService.setRecipientEmail(recipientEmail);

            String message = buildDetailedAlertMessage();
            NotificationService.sendAlert(message);
        } else {
            System.out.println("Vitals are within normal ranges.");
        }
    } catch (Exception e) {
        System.err.println("Error triggering emergency alert: " + e.getMessage());
    }
}

    // this method actually contains the content of the email sent
    private String buildDetailedAlertMessage() {
    return "🚨 EMERGENCY ALERT 🚨\n\n"
         + "Patient's health vitals have crossed critical thresholds.\n"
         + "Please review the following data immediately:\n\n"
         + "Heart Rate: " + heartRate + " bpm (Critical if > " + MAX_HEART_RATE + ")\n"
         + "Blood Pressure: " + bloodPressure + " mmHg (Critical if > " + MAX_BLOOD_PRESSURE + ")\n\n"
         + "Timestamp: " + java.time.LocalDateTime.now() + "\n\n"
         + "Recommended Action: Contact the patient immediately and prepare for emergency response if needed.\n\n"
         + "Stay Safe,\nRemote Health Monitoring System";
} 
}


// class NotificationService validates recipient email address and send alerts via email
class NotificationService {
    private static String recipientEmail = "noorulsaba113@gmail.com"; // fallback/default

    public static void setRecipientEmail(String email) {
        if (email != null && !email.trim().isEmpty()) {
            recipientEmail = email;
        } else {
            System.err.println("️ No email entered. Using default: " + recipientEmail);
        }
    }

    public static void sendAlert(String message) {
        Notifiable sms = new SMSNotification("+1234567890");
        sms.notifyUser(message);

        
        RealEmailNotification.sendEmail(
            recipientEmail,
            "Emergency Alert from Patient",
            message
        );
    }
}


// class PanicButton actually creates a button that is pressed by the patient to trigger emergency alarm
class PanicButton {

    public void pressButton(double heartRate, double bloodPressure, Scanner scanner) {
    System.out.println("\n🚨 Panic button pressed by patient! 🚨");

    EmergencyAlert alert = new EmergencyAlert(heartRate, bloodPressure);
     alert.checkAndTriggerAlert(scanner);
    }
}


// class Message represents a single chat message with sender, content, and timestamp
class Message {
    private String sender;
    private String content;
    private LocalDateTime timestamp;

    public Message(String sender, String content) {
        this.sender = sender;
        this.content = content;
        this.timestamp = LocalDateTime.now();
    }

    public String getFormattedMessage() {
        return "[" + timestamp + "] " + sender + ": " + content;
    }

    public String getSender() {
        return sender;
    }

    public String getContent() {
        return content;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}


// class ChatServer manages storage and broadcasting of chat messages between users.
class ChatServer {
    private List<Message> messages;

    public ChatServer() {
        messages = new ArrayList<>();
    }

    public void addMessage(Message message) {
    messages.add(message);
    System.out.println("New message on ChatServer: " + message.getFormattedMessage());
}

    public List<Message> getMessages() {
    return messages;
}
}


// class ChatClient represents a user in the chat system who can send and receive messages through the ChatServer.
class ChatClient {
    private String username;
    private ChatServer server;

    public ChatClient(String username, ChatServer server) {
        this.username = username;
        this.server = server;
    }

    public void sendMessage(String content) {
    Message message = new Message(username, content);
    server.addMessage(message);
}

   public void receiveMessages() {
    System.out.println(username + " is retrieving messages:");
    for (Message msg : server.getMessages()) {
        System.out.println(msg.getFormattedMessage());
    }
}
}


// class VideoCall actually creates a zoom meeting link that opens in browser
class VideoCall {
    private String meetingLink;

    public VideoCall(String meetingLink) {
        this.meetingLink = meetingLink;
    }

    public void joinCall(String participantName) {
        System.out.println("\n " + participantName + " is joining the video call...");
        System.out.println("Opening the meeting link: " + meetingLink);

        try {
            Desktop desktop = Desktop.getDesktop();
            if (desktop.isSupported(Desktop.Action.BROWSE)) {
                desktop.browse(new URI(meetingLink));
            } else {
                System.err.println("Browser opening not supported on this system.");
            }
        } catch (Exception e) {
            System.err.println("Failed to open browser: " + e.getMessage());
        }
    }
}


// interface notifiable contains method notifyUser used in the classes that implements it
interface Notifiable {
    void notifyUser(String message);
}


// class SMSNotifications displays a message when emergency alarms are triggered
class SMSNotification implements Notifiable {
    private String phoneNumber;

    public SMSNotification(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public void notifyUser(String message) {
    System.out.println("SMS notification sent to " + phoneNumber);
}

}


// class RealEmailNotification actually responsible for sending real-time emergency alerts via email
class RealEmailNotification {
    public static void sendEmail(String to, String subject, String content) {
        final String from = "noorulsaba113@gmail.com"; 
        final String password = "lnsk fsqa wyso euye"; 

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            jakarta.mail.Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(
            jakarta.mail.Message.RecipientType.TO, 
            InternetAddress.parse(to)
);
            message.setSubject(subject);
            message.setText(content);

            Transport.send(message);
            System.out.println("Email sent successfully to " + to);
        } catch (MessagingException e) {
            System.err.println("Failed to send email: " + e.getMessage());
        }
    }
}


// class ReminderService remindes users of their appointment by sending emails (real) and SMS (just a hardcode console message)
class ReminderService {

    public void sendAppointmentReminder(String appointmentDetails) {
        String message = "Appointment Reminder\n\n"
                       + appointmentDetails + "\n\n"
                       + "Please be on time.\n"
                       + "— Remote Health Monitoring System";
        
        RealEmailNotification.sendEmail(
            "patient@example.com",
            "Appointment Reminder",
            message
        );

        Notifiable sms = new SMSNotification("+0987654321");
        sms.notifyUser(message);
    }
}


//  class TestingClass tests if all the classes, objects and their methods are working fine 
public class TestingClass {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        PanicButton panicButton = new PanicButton();

        ChatServer chatServer = new ChatServer();
        ChatClient doctor = new ChatClient("Dr. Smith", chatServer);
        ChatClient patient = new ChatClient("Patient John", chatServer);

        // Create a ReminderService for sending notifications.
        ReminderService reminderService = new ReminderService();

        boolean exit = false;

        while (!exit) {
            System.out.println("\n=== Remote Health Monitoring System ===");
            System.out.println("Select an option:");
            System.out.println("1. Check Vitals and Trigger Emergency Alert");
            System.out.println("2. Press Panic Button");
            System.out.println("3. Chat between Doctor and Patient");
            System.out.println("4. Start a Video Call");
            System.out.println("5. Send Appointment Reminder");
            System.out.println("6. Exit");
            System.out.print("Choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline

            switch (choice) {
                case 1:
                   System.out.println("\n[Emergency Alert] Checking vitals...");
                   System.out.print("Enter heart rate: ");
                   double heartRate = scanner.nextDouble();
                   System.out.print("Enter blood pressure: ");
                   double bloodPressure = scanner.nextDouble();
                   scanner.nextLine(); // consume newline

                
                   EmergencyAlert emergencyAlert = new EmergencyAlert(heartRate, bloodPressure);
                   emergencyAlert.checkAndTriggerAlert(scanner);
                   break;
                case 2:
                   System.out.println("\n[Panic Button] Activating panic button...");
                   System.out.print("Enter heart rate: ");
                   double panicHR = scanner.nextDouble();
                   System.out.print("Enter blood pressure: ");
                   double panicBP = scanner.nextDouble();
                   scanner.nextLine();
                   panicButton.pressButton(panicHR, panicBP,scanner);

                    break;
                case 3:
                    System.out.println("\n[Chat Module] Enter a message from the patient:");
                    String patientMessage = scanner.nextLine();
                    patient.sendMessage(patientMessage);

                    System.out.println("Enter a message from the doctor:");
                    String doctorMessage = scanner.nextLine();
                    doctor.sendMessage(doctorMessage);

                    System.out.println("\n📨 Chat History:");
                    for (Message msg : chatServer.getMessages()) {
                    System.out.println(msg.getFormattedMessage());
    }
                    break;
                case 4:
                    System.out.println("\n[Video Call] Connecting you to Dr. Smith...");
                    String zoomLink = "https://zoom.us/j/1234567890";
                    VideoCall videoCall = new VideoCall(zoomLink);
                    videoCall.joinCall("Patient John");
                    break;
                case 5:
                System.out.println("\n[Reminder Service] Enter appointment details (e.g., 'Your appointment is scheduled on 22-Apr-2025 at 10:00 AM.'):");
                String appointmentDetails = scanner.nextLine();

                System.out.print("Enter recipient email for the appointment reminder: ");
                String reminderEmail = scanner.nextLine();

                NotificationService.setRecipientEmail(reminderEmail);
                String message = "Appointment Reminder\n\n"
                   + appointmentDetails + "\n\n"
                   + "Please be on time.\n"
                   + "— Remote Health Monitoring System";
                 RealEmailNotification.sendEmail(reminderEmail, "Appointment Reminder", message);

                 Notifiable sms = new SMSNotification("+0987654321");
                 sms.notifyUser(message);
                 break;

                case 6:
                    System.out.println("Exiting the system. Goodbye!");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option! Please choose a valid option.");
            }
            System.out.println("------------------------------------------");
        }

    }
}